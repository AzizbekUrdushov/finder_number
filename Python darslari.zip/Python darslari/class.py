class Gamer:
    def __init__(self,nickname,positsion):
        self.name = nickname
        self.pos = positsion
    def tanishtir(self):
        return f"My name is {self.name}, my positsion is {self.pos}"
gamer1 = Gamer('John','attacker')
gamer2 = Gamer('Jo','defender')
gamer3 = Gamer('James','defender')
