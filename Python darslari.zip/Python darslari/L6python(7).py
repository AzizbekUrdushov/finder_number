darsliklar = ["ona tili" , "algebra" ,"tarix" , "chizmachilik"]
darsliklar.append("ing tili")
del darsliklar[0]
darsliklar.insert(1 , "geometriya")
dars = darsliklar.pop(3)
print("Bizda 1-soat " + dars + "darsi")
print("Qolgan darslar: " , darsliklar)


