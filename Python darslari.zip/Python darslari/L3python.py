raidus = 7
p = 3.14
yuz = raidus * p
print("Aylana yuzi",yuz,"ga teng")
#code ishladi