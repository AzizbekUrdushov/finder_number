import json
import googlemaps
from apikey import APIKEY
gmaps = googlemaps.Client(key=APIKEY)
data = gmaps.gecode('Olmazor, Jizzakh , Uzbekistan')
print(data)