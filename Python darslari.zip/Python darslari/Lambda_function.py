print("Sonning (sonlarning) darajasi yoki ildizini hisoblovchi dastur")
amal = input("daraja/ildiz:\n>>>")
if amal == 'daraja':
    natija = lambda x , n:x**n
    son = input("Sonni kiriting:\n>>>")
    daraja = input("Darajani kiriting:\n>>>")
    print(natija(int(son), int(daraja)))
elif amal == 'ildiz':
    natija = lambda x,n:x**n
    son = input("Sonni kiriting:\n>>>")
    print(natija(int(son), 1/2))
else:
    print("Error")
    