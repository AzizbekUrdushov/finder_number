class Gamer:
    def __init__(self,nickname,positsion,level):
        self.name = nickname
        self.pos = positsion
        self.level = level
    def get_name(self):
        return self.name
    def get_positsion(self):
        return self.pos
    def get_fulldata(self):
        return f"{self.name} {self.pos} {self.level}"
    def get_data(self):
        return f"My name is{self.name}, positsion is {self.pos}.I'm {self.level} level "
gamer1 = Gamer("Jo","attacker","9")
gamer2 = Gamer("Bond","defender","6")
gamer3 = Gamer("John","attacker","4")
    
class Zone:
    def __init__(self,name_place):
        self.nam_pl = name_place
        self.num_gamers = 0
        self.gamers = []
    def add_gamer(self,gamer):
        self.gamers.append(gamer)
        self.num_gamers += 1
    def zone_name(self):
        return self.nam.pl
    def get_gamers(self):
        return [gamer.get_fulldata() for gamer in self.gamers]
    def get_num(self):
        return f"gamers:{self.num_gamers}"
zone = Zone("War in mountain")
zone.add_gamer(gamer1)
zone.add_gamer(gamer2)
zone.add_gamer(gamer3)

        
