ism  = input("Ismingizni kirirting\n>>>")
print("Salom " + ism.capitalize())
familya = input("Familyangizni kiriting\n>>>")
ziyofat = "Bayram".title() , "Tug'ulgan kun".title() , "To'y".title()
ziyofat = input("Ziyofatlardan birirni tanlang: Bayram\Tug'ulgan kun\To'y\n>>>")
if ziyofat == "bayram":
    bayram = 'Yangi yil'.title() , 'Navro\'z'.title() , 'Xayit'.title() , 'Mustaqillik bayrami'.title()
    bayram = input("Bayram turini tanlang:\nYangi yil/Navro'z/Xayit/Mustaqillik bayrami\n>>>")
    if bayram == "yangi yil":
        soni = "5" , "10"
        soni = input("Nechta odam taklif qilasiz: 5 , 10\n>>>")
        if soni == "5":
            mehmonlar = []
            print("Mehmonlar ismini kiriting")
            for m in range(int(soni)):
                    mehmonlar.append(input(f"{m+1}-mehmonni ismini kiriting:\n>>>"))
                    for mehmon in mehmonlar:
                            bayram_tak = "1" , "2"
                    if bayram_tak == "1":
                            print("Assalomu alaykum\n" , mehmon.capitalize() ,"sizni kelayotgan yangi yil bayramiga chorlab qolamiz.\nHurmat bilan" + familya.capitalize() , "lar oilasi")
                        
                    elif bayram_tak == "2":
                            print("Assalomu alaykum\n" , mehmon.capitalize() ,"sizni yangi yil munosabati bilan yoziladigan dasturxonimizga taklif qilamiz.\nHurmat bilan" + familya.capitalize() , "lar oilasi")
                    else:
                            print("Noto'g'ri so'rov tanlandi")
        elif soni == "10":
            mehmonlar = []
            print("Mehmonlar ismini kiriting")
            for m in range(soni):
                mehmonlar.append(input(f"{m+1}-mehmonni ismini kiriting"))
                for mehmon in mehmonlar:
                    bayram_tak = "1" , "2"
                    if bayram_tak == "1":
                        print("Assalomu alaykum\n" , mehmon.capitalize() ,"sizni kelayotgan yangi yil bayramiga chorlab qolamiz.\nHurmat bilan" + familya.capitalize() , "lar oilasi")
                    elif bayram_tak == "2":
                        print("Assalomu alaykum\n" , mehmon.capitalize() ,"sizni yangi yil munosabati bilan yoziladigan dasturxonimizga taklif qilamiz.\nHurmat bilan" + familya.capitalize() , "lar oilasi")
                    else:
                        print("Noto'g'ri so'rov tanlandi")
        else:
            print("Odamlar soni 5 yoki 10 ta bo'lishi kerak")
    elif bayram == "navro'z":
        soni = "5" , "10"
        soni = input("Nechata odam taklif qilasiz: 5 , 10\n>>>")
        if soni == "5":
            mehmonlar = []
            print("Mehmonlar ismini kiriting")
            for m in range(soni):
                mehmonlar.append(input(f"{m+1}-mehmonni ismini kiriting"))
                for mehmon in mehmonlar:
                    bayram_tak = "1" , "2"
                    if bayram_tak == "1":
                        print("Assalomu alaykum\n" , mehmon.capitalize() ,"sizni kelayotgan Navro'z bayramiga chorlab qolamiz.\nHurmat bilan" + familya.capitalize() , "lar oilasi")
                    elif bayram_tak == "2":
                        print("Assalomu alaykum\n" , mehmon.capitalize() ,"sizni Navro'z munosabati bilan yoziladigan dasturxonimizga taklif qilamiz.\nHurmat bilan" + familya.capitalize() , "lar oilasi")
                    else:
                        print("Noto'g'ri so'rov tanlandi")
        elif soni == "10":
            mehmonlar = []
            print("Mehmonlar ismini kiriting")
            for m in range(soni):
                mehmonlar.append(input(f"{m+1}-mehmonni ismini kiriting"))
                for mehmon in mehmonlar:
                    bayram_tak = "1" , "2"
                    if bayram_tak == "1":
                        print("Assalomu alaykum\n" , mehmon.capitalize() ,"sizni kelayotgan Navro'z bayramiga chorlab qolamiz.\nHurmat bilan" + familya.capitalize() , "lar oilasi")
                    elif bayram_tak == "2":
                        print("Assalomu alaykum\n" , mehmon.capitalize() ,"sizni Navro'z munosabati bilan yoziladigan dasturxonimizga taklif qilamiz.\nHurmat bilan" + familya.capitalize() , "lar oilasi")
                    else:
                        print("Noto'g'ri so'rov tanlandi")
        else:
            print("Odamlar soni 5 yoki 10 ta bo'lishi kerak")
    elif bayram == "xayit":
        soni = "5" , "10"
        soni = input("Nechata odam taklif qilasiz: 5 , 10\n>>>")
        if soni == "5":
            mehmonlar = []
            print("Mehmonlar ismini kiriting")
            for m in range(soni):
                mehmonlar.append(input(f"{m+1}-mehmonni ismini kiriting"))
                for mehmon in mehmonlar:
                    bayram_tak = "1" , "2"
                    if bayram_tak == "1":
                        print("Assalomu alaykum\n" , mehmon.capitalize() ,"sizni kelayotgan Xayit bayramiga chorlab qolamiz.\nHurmat bilan" + familya.capitalize() , "lar oilasi")
                    elif bayram_tak == "2":
                        print("Assalomu alaykum\n" , mehmon.capitalize() ,"sizni Xayit munosabati bilan yoziladigan dasturxonimizga taklif qilamiz.\nHurmat bilan" + familya.capitalize() , "lar oilasi")
                    else:
                        print("Noto'g'ri so'rov tanlandi")
        elif soni == "10":
            mehmonlar = []
            print("Mehmonlar ismini kiriting")
            for m in range(soni):
                mehmonlar.append(input(f"{m+1}-mehmonni ismini kiriting"))
                for mehmon in mehmonlar:
                    bayram_tak = "1" , "2"
                    if bayram_tak == "1":
                        print("Assalomu alaykum\n" , mehmon.capitalize() ,"sizni kelayotgan Xayit bayramiga chorlab qolamiz.\nHurmat bilan" + familya.capitalize() , "lar oilasi")
                    elif bayram_tak == "2":
                        print("Assalomu alaykum\n" , mehmon.capitalize() ,"sizni Xayit munosabati bilan yoziladigan dasturxonimizga taklif qilamiz.\nHurmat bilan" + familya.capitalize() , "lar oilasi")
                    else:
                        print("Noto'g'ri so'rov tanlandi")
        else:
            print("Odamlar soni 5 yoki 10 ta bo'lishi kerak")
    else:
        soni = "5" , "10"
        soni = input("Nechata odam taklif qilasiz: 5 , 10\n>>>")
        if soni == "5":
            mehmonlar = []
            print("Mehmonlar ismini kiriting")
            for m in range(soni):
                mehmonlar.append(input(f"{m+1}-mehmonni ismini kiriting"))
                for mehmon in mehmonlar:
                    bayram_tak = "1" , "2"
                    if bayram_tak == "1":
                        print("Assalomu alaykum\n" , mehmon.capitalize() ,"sizni kelayotgan Mustaqillik bayramiga chorlab qolamiz.\nHurmat bilan" + familya.capitalize() , "lar oilasi")
                    elif bayram_tak == "2":
                        print("Assalomu alaykum\n" , mehmon.capitalize() ,"sizni Mustaqillik bayrami munosabati bilan yoziladigan dasturxonimizga taklif qilamiz.\nHurmat bilan" + familya.capitalize() , "lar oilasi")
                    else:
                        print("Noto'g'ri so'rov tanlandi")
        elif soni == "10":
            mehmonlar = []
            print("Mehmonlar ismini kiriting")
            for m in range(soni):
                mehmonlar.append(input(f"{m+1}-mehmonni ismini kiriting"))
                for mehmon in mehmonlar:
                    bayram_tak = "1" , "2"
                    if bayram_tak == "1":
                        print("Assalomu alaykum\n" , mehmon.capitalize() ,"sizni kelayotgan Mustaqillik bayramiga chorlab qolamiz.\nHurmat bilan" + familya.capitalize() , "lar oilasi")
                    elif bayram_tak == "2":
                        print("Assalomu alaykum\n" , mehmon.capitalize() ,"sizni Mustaqillik bayrami munosabati bilan yoziladigan dasturxonimizga taklif qilamiz.\nHurmat bilan" + familya.capitalize() , "lar oilasi")
                    else:
                        print("Noto'g'ri so'rov tanlandi")
        else:
            print("Odamlar soni 5 yoki 10 ta bo'lishi kerak")
elif ziyofat == "tug'ulgan kun":
    soni = "5" , "10"
    soni = input("Nechata odam taklif qilasiz: 5 , 10\n>>>")
    if soni == "5":
        mehmonlar = []
        print("Mehmonlar ismini kiriting")
        for m in range(soni):
            mehmonlar.append(input(f"{m+1}-mehmonni ismini kiriting"))
            for mehmon in mehmonlar:            
                bayram_tak = "1" , "2"
                if bayram_tak == "1":
                    soat = input("Soatni kiriting")
                    print("Assalomu alaykum\n" , mehmon.capitalize() ,"sizni", + soat +  "da kelayotgan", + ism.capitalize() + familya.capitalize() , "ning tavallud bayramiga chorlab qolamiz.\nHurmat bilan" + familya.capitalize() , "lar oilasi")
                elif bayram_tak == "2":
                    print("Assalomu alaykum\n" , mehmon.capitalize() ,"sizni",+ soat+"da " + ism.capitalize() + familya.capitalize(),  "ning tug'ilgan kun munosabati bilan yoziladigan dasturxonimizga taklif qilamiz.\nHurmat bilan" + familya.capitalize() , "lar oilasi")
                else:
                    print("Noto'g'ri so'rov tanlandi")
    elif soni == "10":
        mehmonlar = []
        print("Mehmonlar ismini kiriting")
        for m in range(soni):
            mehmonlar.append(input(f"{m+1}-mehmonni ismini kiriting"))
            for mehmon in mehmonlar:            
                bayram_tak = "1" , "2"
                if bayram_tak == "1":
                    print("Assalomu alaykum\n" , mehmon.capitalize() ,"sizni"+ soat +"da kelayotgan", + ism.capitalize() + familya.capitalize() ,"ning tavallud bayramiga chorlab qolamiz.\nHurmat bilan" + familya.capitalize() , "lar oilasi")
                elif bayram_tak == "2":
                    print("Assalomu alaykum\n" , mehmon.capitalize() ,"sizni",+ soat+ "da " + ism.capitalize() + familya.capitalize() , "ning tug'ilgan kuni munosabati bilan yoziladigan dasturxonimizga taklif qilamiz.\nHurmat bilan" + familya.capitalize() , "lar oilasi")
                else:
                    print("Noto'g'ri so'rov tanlandi")
    else:
        print("Odamlar soni 5 yoki 10 ta bo'lishi kerak")
else:
    toy_t = "nigox to'y" "sunnat to'y"
    toy_t = input("To'y turini tanlang:Nigox to'y/Sunnat to'y\n>>>")
    if toy_t == "nigox to'y":
        soni = "5" , "10"
        soni = input("Nechta odam taklif qilasiz: 5 , 10\n>>>")
        if soni == "5":
            mehmonlar = []
            print("Mehmonlar ismini kiriting")
            for m in range(soni):
                mehmonlar.append(input(f"{m+1}-mehmonni ismini kiriting"))
                for mehmon in mehmonlar:
                    bayram_tak = "1" , "2"
                    if bayram_tak == "1":
                        kuyov = input("Kuyovning ismini kiritng\n>>>")
                        kelin = input("Kelinning ismini kiriting:\n>>>")
                        soat = input("Soatni kiriting\n>>>")
                        print("Assalomu alaykum ", + mehmon.capitalize() + "\nsizni ", + soat + "da " + kuyov + "bek va " + kelin + "oyning to'ylariga taklif qilamiz " )
                    elif bayram_tak == "2":
                        kuyov = input("Kuyovning ismini kiritng\n>>>")
                        kelin = input("Kelinning ismini kiriting:\n>>>")
                        soat = input("Soatni kiriting\n>>>")
                        print("Assalomu alaykum "+ mehmon.capitalize() + "\n sizni ", + soat + "da" + kuyov + "bek va " + kelin + "oyning to'ylari munosabati bilan\n yoziladigan dasturxonimizga taklif qilamiz\nHurmat bilan " + familya + "lar oilasi" )
                    else:
                        print("Noto'gri so'rov kiritildi")
        elif soni == "10":
            mehmonlar = []
            print("Mehmonlar ismini kiriting")
            for m in range(soni):
                mehmonlar.append(input(f"{m+1}-mehmonni ismini kiriting"))
                for mehmon in mehmonlar:
                    bayram_tak = "1" , "2"
                    if bayram_tak == "1":
                        kuyov = input("Kuyovning ismini kiritng\n>>>")
                        kelin = input("Kelinning ismini kiriting:\n>>>")
                        soat = input("Soatni kiriting\n>>>")
                        print("Assalomu alaykum ", + mehmon.capitalize() + "\nsizni ", + soat + "da " + kuyov + "bek va " + kelin + "oyning to'ylariga taklif qilamiz " )
                    elif bayram_tak == "2":
                        kuyov = input("Kuyovning ismini kiritng\n>>>")
                        kelin = input("Kelinning ismini kiriting:\n>>>")
                        soat = input("Soatni kiriting\n>>>")
                        print("Assalomu alaykum "+ mehmon.capitalize() + "\n sizni ", + soat + "da" + kuyov + "bek va " + kelin + "oyning to'ylari munosabati bilan\n yoziladigan dasturxonimizga taklif qilamiz\nHurmat bilan " + familya + "lar oilasi" )
                    else:
                        print("Noto'gri so'rov kiritildi")
    elif toy_t == "sunnat to'y":
        soni = "5" , "10"
        soni = input("Nechta odam taklif qilasiz: 5 , 10\n>>>")
        if soni == "5":
            mehmonlar = []
            print("Mehmonlar ismini kiriting")
            for m in range(soni):
                mehmonlar.append(input(f"{m+1}-mehmonni ismini kiriting"))
                for mehmon in mehmonlar:
                    bayram_tak = "1" , "2"
                    if bayram_tak == "1":
                        bola = input("Bolaning ismini kirirting:\n>>>")
                        soat = input("Soatni kiriting:\n>>>")
                        print("Assalomu alaykum " + mehmon.capitalize() + "\nsizni "+ soat + "da " + bola + "ning sunnat to'yiga taklif qilamiz")
                    elif bayram_tak == "2":
                        bola = input("Bolaning ismini kirirting:\n>>>")
                        soat = input("Soatni kiriting:\n>>>")
                        print("Assalomu alaykum "  + mehmon.capitalize() +  "\nsizi "  + soat +  "da "  + bola +  "ning sunnat to'yi munoabati bilan yoziladigan dastuzxonimizga taklif qilamiz.\nHurmat bilan "  + familya +  "lar oilasi")
                    else:
                        print("so'rov xato")
        elif soni == "10":
            mehmonlar = []
            print("Mehmonlar ismini kiriting")
            for m in range(soni):
                mehmonlar.append(input(f"{m+1}-mehmonni ismini kiriting"))
                for mehmon in mehmonlar:
                    bayram_tak = "1" , "2"
                    if bayram_tak == "1":
                        bola = input("Bolaning ismini kirirting:\n>>>")
                        soat = input("Soatni kiriting:\n>>>")
                        print("Assalomu alaykum " + mehmon.capitalize() + "\nsizni "+ soat + "da " + bola + "ning sunnat to'yiga taklif qilamiz")
                    elif bayram_tak == "2":
                        bola = input("Bolaning ismini kirirting:\n>>>")
                        soat = input("Soatni kiriting:\n>>>")
                        print("Assalomu alaykum "  + mehmon.capitalize() +  "\nsizi "  + soat +  "da "  + bola +  "ning sunnat to'yi munoabati bilan yoziladigan dastuzxonimizga taklif qilamiz.\nHurmat bilan "  + familya +  "lar oilasi")
                    else:
                        print("so'rov xato")
    else:
        print("Bizning ro'yxatimizda bunday to'y yo'q")
        
                                 
        