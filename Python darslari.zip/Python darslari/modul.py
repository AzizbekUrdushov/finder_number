print("Bu dasturda siz do'stlaringizni ismini va qizlarni ismini kiritsangiz\nularni sevgi testini hisoblab beradi")
import random as r
dostlar = []
n =1
while True:
    savol = f"{n}-do'stingiz ismini kiriting:\n>>>"
    test = input(savol)
    dostlar.append(test)
    davr = input("Yana do'stingizni kiritasizmi:ha/yo'q\n>>> ")
    n+=1
    if davr != 'ha':
        break
qizlar = []
n = 1
while True:
    savol = f"{n}-qizni ismini kiriting:\n>>>"
    test = input(savol)
    qizlar.append(test)
    davr = input("Yana qizni kiritasizmi:ha/yo'q\n>>>")
    n+=1
    if davr != 'ha':
        break
dost = r.choice(dostlar)
qiz = r.choice(qizlar)
son = r.randint(60,100)
print(f"{dost.capitalize()} va {qiz.capitalize()}ning sevish darajasi:" + str(son) + "%")