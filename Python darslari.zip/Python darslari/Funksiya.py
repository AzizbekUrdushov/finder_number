def baho_qoy(ismi,bahosi):
    baholari = {'ism':ismi,
                'baho':bahosi}
    return baholari
print("O'quvchilarga baho qo'yamiz")
baholar = []
print('\nMalumotlarni kiriting')
while True:
    ismi = input("O'quvchining ismini kiriting:\n>>>")
    bahosi = input(ismi.capitalize() + 'ning bahosini kiriting:\n>>>')
    baholar.append(baho_qoy('ismi','bahosi'))
    davr = input("Yana baholaysizmi:ha/yo'q\n>>>")
    if davr != 'ha':
        break
print("Bizda baholangan o'quvchilar:")
print(f"{baholar['ism'].capitalize()}ning bahosi:{baholar['baho'].capitalize()}")