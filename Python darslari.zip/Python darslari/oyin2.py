import random as r
def son_top(x=10):
    son = r.randint(1,x)
    print(f"Men 1 dan {x} gacha son o'yladim topa olasizmi")
    taxminlar = 0  
    while True:
        taxminlar+=1
        taxmin = int(input(">"))
        if son>taxmin:
            print("Men o'ylagan son bundan kattaroq.Yana urinib ko'ring")
        elif son<taxmin:
            print("Men o'ylagan son bundan kichikroq.Yana urinib ko'ring")
        else:
            break
    print(f"Tabriklaymiz topdingiz.{taxminlar}ta urunish bilan")
    return taxminlar