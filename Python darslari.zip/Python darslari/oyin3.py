import random as r
def son_top_pc(x=10):
    input(f"1 dan {x} gacha son o'ylang va enter tugmasini bosing.Men topaman")
    maxi = x
    mini = 1
    taxminlar = 0
    while True:
        taxminlar += 1
        if mini != maxi:
            taxmin = r.randint(mini,maxi)
        else:
            taxmin = mini
        natija = input(f"Siz {taxmin} sonini o'yladingiz.To'gri(t),\nmen o'ylagan son bundan kattaroq(+),\nmen o'ylagan son bundan kichikroq(-) ".lower())
        if natija == '-':
            maxi = taxmin -1
        elif natija == '+':
            mini = taxmin + 1
        else:
            break
    print(f"Topdim!{taxminlar} ta urunish bilan ")
    return taxminlar