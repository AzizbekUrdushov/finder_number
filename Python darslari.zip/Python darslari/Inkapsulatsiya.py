from uuid import uuid4
class Talaba:
    def __init__(self,name,dagree,univercity,mark=5):
        self.name=name
        self.dagree=dagree
        self.univercity=univercity
        self.__mark=mark
        self.__id=uuid4()
    def get_mark(self):
        return f"{self.name}'s mark:{self.__mark}"
    def get_id(self):
        return self.__id
    def add_dagree(self,dagree):
        return "Your dagree\n>>>"
        if dagree>=1:
            self.dagree += dagree
        else:
            return "Error"
        
            