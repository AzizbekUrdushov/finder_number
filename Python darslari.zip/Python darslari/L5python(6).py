daromad = int(input("Oylik daromadingizni kiriting: "))
xarajat = 1_300_000
s_daromad = daromad - xarajat
print("Sizning oylik sof daromadingiz ", s_daromad)


t_yil = 1441
ism = "Alisher Navoiy"
jamlanma = ism + " " + str(t_yil) + " yilda tugilgan"
print(jamlanma)

temp = input("Tana haroratingizni kiriting: ")
TEMP = 36.6
a = float(temp) - TEMP
jami = "Sizning tana haroratingiz " + str(a) + "ga ko'p"
print(jami) 