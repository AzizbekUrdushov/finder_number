import oyin2 as o2
import oyin3 as o3

def play(x=10):
    davr = True
    while davr:
        taxminlar_f = o2.son_top(x)
        taxminlar_pc = o3.son_top_pc(x)
        if taxminlar_f>taxminlar_pc:
            print(f"\nMen yutdim!Menda {taxminlar_pc}ta urinish.\nSizda {taxminlar_f}ta urinish")
        elif taxminlar_f<taxminlar_pc:
            print(f"\nSiz yutdingiz!Sizda{taxminlar_f}ta urinish.\nMenda{taxminlar_pc}ta urinish")
        else:
            print(f"\nDurrang!Sizda{taxminlar_pc}ta urinish.\nMenda{taxminlar_f}ta urinish")
        davr = int(input("Yana o'ynaysizmi:Ha(1)/Yo'q(0)\n>>>"))
print(play(x=10))