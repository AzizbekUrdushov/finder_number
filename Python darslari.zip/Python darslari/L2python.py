print("""Bugungi dars izoh yozish sytax errorlarni to'girlash qo'shtirnoq yoki
1tirnoqlardan foydalanish qator tashish sonlar ya'ni 4ning kvadrati""",4**2,"""
ni o'rganish""") #dars tamom