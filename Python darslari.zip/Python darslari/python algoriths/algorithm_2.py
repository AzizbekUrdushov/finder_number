for i in range(101):
    i = [i]


         
def search():

    while True:
        t = 30
        index = i[-1]
        l = 0 
        h = index
        
        m = (l + h)//2
        mid = int(m)
        if l > h:
            print("Error!")
        if i[mid] == t:
            print(mid)
            break
        elif m < t:
            l = mid + 1
        else:
            h = mid - 1
    
    