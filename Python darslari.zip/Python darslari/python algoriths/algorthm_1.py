i = 1
while True:
    n = input("Nechi factorialni hisoblamoqchisiz?\n>>>")
    n = int(n)
    if n >= 1 :
        break
    else:
        print("musbat son kiritng")
        
if n == i:
    print(f"{n}ning factoriali {i}ga teng")
else:
    factorial = 1
    i = 1
    for i in range(1,n+1):
        factorial *= i
    print(f"{n}ning factoriali {factorial}ga teng")
            
            
        
        
