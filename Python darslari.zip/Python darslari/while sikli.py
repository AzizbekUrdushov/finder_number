amal = input("Amallardan birirni tanlang: 'Daraja', 'Ildiz', 'Ko'paytirish', Qo'shish':\n>>> ")
if amal == 'Ildiz'.lower():
    print("Sonning ildizini hisoblovchi dastur")
    savol = "Istalgan sonni kiriting, "
    savol+= "(dasturni to'xtatish uchun 'stop' deb yozing ):\n>>>"
    qiymat = ''
    while qiymat != 'stop':
        qiymat = input(savol)
        if qiymat != 'stop':
            print(float(qiymat)**0.5)
    print("Dastur uxlashga yotdi")
elif amal == 'Daraja'.lower():
    print("Sonning kvadratini hisoblovchi dastur")
    savol = "Istalgan sonni kiriting, "
    savol+= "(dasturni to'xtatish uchun 'stop' deb yozing ):\n>>>"
    qiymat = ''
    while qiymat != 'stop':
          qiymat = input(savol)
          if qiymat != 'stop':
              print(float(qiymat)**2)
    print("Dastur uxlashga yotdi")
elif amal == 'Qo\'shish'.lower():
    print("Sonni songa qo'shuvchi dastur")
    sonlar = []
    n = 1
    while True:
        savol = f"{n}-sonni kiriting:\n>>>"
        qosh = input(savol)
        sonlar.append(int(qosh))
        davr = input("Yana son qo'shmoqchimisiz: Ha/Yo'q\n>>>")
        n+=1
        if davr != 'Ha'.lower():
            break
    natija = sum(sonlar)
    print(natija)
elif amal == 'Ko\'paytirish'.lower():
    print("Sonni songa ko'patiruvchi dastur")
    sonlar = []
    n = 1
    while True:
        savol = f"{n}-sonni kiriting:\n>>>"
        kop = input(savol)
        sonlar.append(int(kop))
        davr = input("Yana son qo'shmoqchimisiz: Ha/Yo'q\n>>>")
        n+=1
        if davr != 'Ha'.lower():
            break
    for son in sonlar:
        natija = 1
        natija*=son
        print(natija)
        