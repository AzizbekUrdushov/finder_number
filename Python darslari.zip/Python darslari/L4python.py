print("men hozir stringni metodini ishlatyapman".upper())
print("men hozir stringni  metodini ishlatyapman".lower())      
print("men hozir stringni  metodini ishlatyapman".title())
print("men hozir stringni metodini ishlatyapman".capitalize())
a = "          olma           "
print("Men " + a.lstrip() + " yeyapman")
print("Men " + a.rstrip() + " yeyapman")
print("Men " + a.strip() + " yeyapan")


ism = input("Ismingiz nima ")
print("Salom " + ism.title())
    