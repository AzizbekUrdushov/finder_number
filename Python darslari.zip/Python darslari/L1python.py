# -*- coding: utf-8 -*-
"""
Created on Wed Jul 12 01:17:39 2023

@author: User
"""
print("hello world")
sonlar = [1 , 2 , 3 , 4]
j = sum(sonlar)
print(j)
soni = "5" , "10"
soni = input("sonni kiriting 5 , 10 :")
if soni == "5":
    print("5")
elif soni == "10":
    print("10")
else:
    print("Xato")
print(25*0.5)