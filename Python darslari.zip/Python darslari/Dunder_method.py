class Car:
    def __init__(self,company,model,colour,year,km):
        self.company = company
        self.model = model
        self.colour = colour
        self.year = year
        self.__km = km
    def __repr__(self):
        return f"{self.company.capitalize()} {self.year}-year {self.colour} {self.model.capitalize()}"
    def get_km(self):
        return self.__km
         
            
car1 = Car("Bugatti","chyron","dark and red", "2022", "2000")
print(car1)