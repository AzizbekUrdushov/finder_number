mahsulotlar = []
print("Sotib olmoqchi bo'lgan 4 ta mahsulotlarni yozing")
for m in range(4):
    mahsulotlar.append(input(f"{m+1} mahsulotni kiriting: "))
print("Endi esa narxlarini kiriting")
narxlari = []
for mahsulot in mahsulotlar:
    narxlari.append(input(mahsulot.capitalize() + "ning narxini kiriting: "))
jami = int(narxlari[0]) + int(narxlari [1]) + int(narxlari[2]) + int(narxlari[3])
print("Hamma mahsulot uchun ketadigan pul: " + str(jami))
    