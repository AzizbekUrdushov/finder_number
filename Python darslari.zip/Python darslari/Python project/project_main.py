import player1 as p1
import player2 as p2
def find_winner():
    if p1.total_time < p2.total_time2:
        print("\nCongratulation!You win Player1 with "+ p1.total_time + "seconds")
    elif p1.total_time > p2.total_time2:
        print("\nCongratulation!You win Player2 with " + p2.total_time2 +"seconds")
    else:
        print("\nYour time are equal.Both of you are winners of our game")
print(find_winner())

    
 
        

    
        

