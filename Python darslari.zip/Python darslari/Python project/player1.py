import random as r
import time as t
OPERATORS = ["+","-","*"]
MIN_OPER = 3
MAX_OPER = 12
TOTAL_PROB = 5
scores = ["Nice" , "Excelant" , "Good job" , "Great"]

def generation_prob():
    left = r.randint(MIN_OPER,MAX_OPER)
    right = r.randint(MIN_OPER,MAX_OPER)
    operator = r.choice(OPERATORS)
    
    score = str(left) + " " + operator + " " + str(right)
    answer = eval(score)
    return score , answer




wrong = 0
print("Player1 turn ")
print("You have 5 problems")
input("Press enter to start")
print("---------------------")

start_time = t.time()


for i in range(TOTAL_PROB):
    score , answer = generation_prob()
    while True:
        player_answer = input("Problem #" + str(i + 1) + ": " + score + " = ")
        if player_answer == str(answer):
            break
        wrong += 1
                
                
end_time = t.time()
total_time = round(end_time - start_time ,2)
total_time = str(total_time)
        
print("---------------------")
print(r.choice(scores))
print("You finish at:" + total_time + "seconds\n")
