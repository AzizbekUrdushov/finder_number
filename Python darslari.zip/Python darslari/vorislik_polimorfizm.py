class Transport:
    def __init__(self,company,year,color):
        self.company = company
        self.year = year
        self.color = color
    def get_info(self):
        return f"Company:{self.company.capitalize()}.Year:{self.year}.Color:{self.color}"
class Car(Transport):
    def __init__(self,company,year,color,name):
        super().__init__(company, year, color)
        self.name = name
    def get_name(self):
        return f"This car's name {self.company.capitalize()} {self.name.capitalize()}"
    
    
    
        